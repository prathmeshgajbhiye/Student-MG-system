/**
 * @Project Student management system
 * @Package com.YUbuntu.basicDao
 * @Description TODO
 * @Author #YUbuntu
 * @Date Dec 26, 2018-7:45:49 PM
 * @version 1.0
 */
package com.YUbuntu.basicDao;